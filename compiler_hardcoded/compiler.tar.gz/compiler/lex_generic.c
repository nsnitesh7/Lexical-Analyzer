#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"y.tab.h"
#define KEYWORDS 29   
int T[50][50],count=0,type;
char str[100],c,char_set[100];

int  keyword_count=0;

char k[KEYWORDS][10]= {"typedef","short","sizeof" ,"int","float","double","bool","extern","char",
		       "signed","unsigned","for","while","do","return","struct","const","void","switch",
		       "break","case","continue","goto","long","static","union","volatile","default","enum"};         //list of keywords

int yylex(yylType* yylP);
int main()
{
    int i,j,token;
    char c;
    FILE *fp;
    yylType* yylP;

    yylP = (yylType*)malloc(sizeof(yylType));                     //allocating space to the pointer


}


int yylex(yylType* yylP)
{
  int current_state=0,prev_state,i=0,j=0,comment=0,index;
  char lexeme[50];
  type = 0;
  
  if(count==0)                                                               //reading the first character from the user
    {
      count = 1;
      scanf("%c",&c);
    }
//  printf("%c---> \n",c);
  while(1)
    {
      if(c == EOF)                                                             //if the end of input is reached
	{
	    return 0;
	}
      prev_state = current_state;

      for(j=0;sizeof(char_set);j++)
      if (char_set[j]==c)
      index = j;

      if((c >= 32) && (c < 127)){
	current_state = T[current_state][index];
	str[i++] = c;
	}
      else                                                                  //start from the beginning
	{
	  current_state = start_state;                      
	  //count = 0;
        }
      if(isfinal(current_state)==0)
	current_state = start_state;
      if((current_state == start_state) && isfinal(prev_state)
	{
		str[i]='\0';
		if(strcmp(str,"true") == 0 || strcmp(str,"false") == 0)                 //if boolean constants are identified
		{
		  type = 1;
		  yylP->string = str;
		  return BOOL_OPTR;
		}
 		else if(isKeyword(str){
		type = 2;
		yylP->integer = 540 + j*10;
		return KEYOWRDS;
		}
		else {
		type = 1;
		yylP->string = str;                                               
		return IDENTIFIER; 
		}
      
        













